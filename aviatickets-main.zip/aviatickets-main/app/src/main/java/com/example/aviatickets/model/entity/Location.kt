package com.example.aviatickets.model.entity

data class Location(
    val cityName: String,
    val code: String
)